﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCBuilderApp
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void btnStartBuild_Click(object sender, EventArgs e)
        {
            BuilderForm bf = new BuilderForm();
            bf.Show();
        }

        private void btnTransactions_Click(object sender, EventArgs e)
        {
            TransactionHistoryForm tf = new TransactionHistoryForm();
            tf.Show();
        }
    }
}
