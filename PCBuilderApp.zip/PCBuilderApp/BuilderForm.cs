﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace PCBuilderApp
{
    public partial class BuilderForm : Form
    {
        string connStr = @"Data Source=.\SQLEXPRESS;Initial Catalog=PCBuilderDB;Integrated Security=True";
        public BuilderForm()
        {
            InitializeComponent();
        }
        private void LoadComponents(string category, ComboBox cb)
        {
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("SELECT Model FROM Components WHERE Category=@cat", conn);
                cmd.Parameters.AddWithValue("@cat", category);

                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    cb.Items.Add(reader["Model"].ToString());
                }
            }
        }

        private void BuilderForm_Load(object sender, EventArgs e)
        {
            LoadComponents("Motherboard", cbMotherboard);
            LoadComponents("Processor", cbProcessor);
            LoadComponents("GPU", cbGPU);
            LoadComponents("RAM", cbRAM);
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            ProductForm pf = new ProductForm();

            pf.motherboard = cbMotherboard.Text;
            pf.processor = cbProcessor.Text;
            pf.gpu = cbGPU.Text;
            pf.ram = cbRAM.Text;

            pf.Show();
        }

        private void cbProcessor_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
