﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCBuilderApp
{
    public partial class ProductForm : Form
    {
        public ProductForm()
        {
            InitializeComponent();
        }
        public string motherboard, processor, gpu, ram;

        private void ProductForm_Load(object sender, EventArgs e)
        {
            lblSummary.Text =
        "Motherboard: " + motherboard + "\n" +
        "Processor: " + processor + "\n" +
        "GPU: " + gpu + "\n" +
        "RAM: " + ram;
        }

        private void btnCheckout_Click(object sender, EventArgs e)
        {
            CheckoutForm cf = new CheckoutForm();
            cf.productSummary = lblSummary.Text;
            cf.Show();
        }
    }
}
