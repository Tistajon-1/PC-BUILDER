﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCBuilderApp
{
    public partial class CheckoutForm : Form
    {
        public CheckoutForm()
        {
            InitializeComponent();

        }
        public string productSummary;

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void CheckoutForm_Load(object sender, EventArgs e)
        {
            lblProduct.Text = productSummary;
        }

        private void btnPurchase_Click(object sender, EventArgs e)
        {
        using (SqlConnection conn = new SqlConnection(connStr))
        {
               conn.Open();
               SqlCommand cmd = new SqlCommand(
            "INSERT INTO Transactions (Username, ContactNumber, ProductSummary, TotalPrice) VALUES (@u,@n,@p,@t)", conn);

        cmd.Parameters.AddWithValue("@u", txtUsername.Text);
        cmd.Parameters.AddWithValue("@n", txtNumber.Text);
        cmd.Parameters.AddWithValue("@p", productSummary);
        cmd.Parameters.AddWithValue("@t", 0); // you can compute later

        cmd.ExecuteNonQuery();
    }

    MessageBox.Show("Purchase Successful!");
}
        
    }
}
