﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCBuilderApp
{
    public partial class TransactionHistoryForm : Form
    {
        public TransactionHistoryForm()
        {
            InitializeComponent();
        }

        private void TransactionHistoryForm_Load(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connStr))
    {
        conn.Open();
        SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Transactions", conn);
        DataTable dt = new DataTable();
        da.Fill(dt);

        dataGridView1.DataSource = dt;
        }
    }
}
